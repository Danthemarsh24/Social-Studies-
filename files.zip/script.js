document.getElementById('helloBtn').addEventListener('click', function() {
  alert('Hello! Welcome to your new website 🥳');
});