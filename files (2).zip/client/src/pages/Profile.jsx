import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";

function Profile() {
  const { id } = useParams();
  const [user, setUser] = useState({});
  useEffect(() => {
    axios.get(`http://localhost:5000/api/users/${id}`).then(res => setUser(res.data));
  }, [id]);
  return (
    <div>
      <img src={user.avatar} alt="" width={64} />
      <h2>{user.username}</h2>
      <p>{user.bio}</p>
    </div>
  );
}
export default Profile;