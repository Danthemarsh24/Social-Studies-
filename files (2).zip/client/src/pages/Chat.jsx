import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import io from "socket.io-client";

const socket = io("http://localhost:5000");

function Chat() {
  const { roomId } = useParams();
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  useEffect(() => {
    socket.emit("joinRoom", roomId);
    socket.on("chatMessage", (msg) => setMessages((prev) => [...prev, msg]));
    return () => socket.off("chatMessage");
  }, [roomId]);

  const send = () => {
    socket.emit("chatMessage", { room: roomId, message: text });
    setText("");
  };

  return (
    <div>
      <h2>Group Chat</h2>
      <div style={{height:300, overflowY:"scroll", border:"1px solid #eee"}}>
        {messages.map((msg, idx) => <div key={idx}>{msg}</div>)}
      </div>
      <input value={text} onChange={e=>setText(e.target.value)} />
      <button onClick={send}>Send</button>
    </div>
  );
}
export default Chat;