import React, { useEffect, useState } from "react";
import axios from "axios";

function Groups() {
  const [groups, setGroups] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:5000/api/groups").then(res => setGroups(res.data));
  }, []);
  return (
    <div>
      <h2>Study Groups</h2>
      {groups.map(group => (
        <div key={group._id} style={{border: "1px solid #ccc", margin: 10, padding:10}}>
          <h4>{group.name}</h4>
          <p>{group.description}</p>
          <p>Members: {group.members.length}</p>
        </div>
      ))}
    </div>
  );
}
export default Groups;