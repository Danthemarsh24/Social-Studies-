import React, { useState } from "react";
import axios from "axios";

function Register() {
  const [form, setForm] = useState({username: "", email: "", password: ""});
  const handleChange = e => setForm({...form, [e.target.name]: e.target.value});
  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/users/register", form);
    window.location.href = "/login";
  };
  return (
    <form onSubmit={handleSubmit}>
      <h2>Register</h2>
      <input name="username" placeholder="Username" onChange={handleChange} />
      <input name="email" placeholder="Email" onChange={handleChange} />
      <input name="password" placeholder="Password" type="password" onChange={handleChange} />
      <button type="submit">Register</button>
    </form>
  );
}
export default Register;