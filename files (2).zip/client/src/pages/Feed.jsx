import React, { useEffect, useState } from "react";
import axios from "axios";

function Feed() {
  const [posts, setPosts] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:5000/api/posts").then(res => setPosts(res.data));
  }, []);
  return (
    <div>
      <h2>Feed</h2>
      {posts.map(post => (
        <div key={post._id} style={{border: "1px solid #ccc", margin: 10, padding:10}}>
          <div>
            <img src={post.author.avatar} alt="" width={32} style={{borderRadius:"50%"}} /> {post.author.username}
          </div>
          <div>{post.content}</div>
          <div>{new Date(post.createdAt).toLocaleString()}</div>
          <div>Likes: {post.likes.length} | Comments: {post.comments.length}</div>
        </div>
      ))}
    </div>
  );
}
export default Feed;