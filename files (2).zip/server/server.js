const app = require("./app");
const http = require("http");
const mongoose = require("mongoose");
const { Server } = require("socket.io");

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

// Real-time chat setup
io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("joinRoom", (room) => socket.join(room));
  socket.on("chatMessage", ({ room, message }) => {
    io.to(room).emit("chatMessage", message);
  });

  socket.on("disconnect", () => console.log("User disconnected:", socket.id));
});

mongoose.connect("mongodb://localhost:27017/socialstudies")
  .then(() => {
    server.listen(5000, () => console.log("Server running on port 5000"));
  })
  .catch((err) => console.error(err));