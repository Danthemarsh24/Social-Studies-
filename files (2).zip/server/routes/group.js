const express = require("express");
const router = express.Router();
const Group = require("../models/Group");

// Get all groups
router.get("/", async (req, res) => {
  const groups = await Group.find().populate("members", "username avatar");
  res.json(groups);
});

// Create group
router.post("/", async (req, res) => {
  const { name, description, userId } = req.body;
  const group = new Group({ name, description, members: [userId] });
  await group.save();
  res.status(201).json(group);
});

// Join group
router.post("/:id/join", async (req, res) => {
  const { userId } = req.body;
  const group = await Group.findById(req.params.id);
  if (!group) return res.status(404).json({ error: "Group not found" });
  if (!group.members.includes(userId)) {
    group.members.push(userId);
    await group.save();
  }
  res.json(group);
});

// Send group message
router.post("/:id/message", async (req, res) => {
  const { userId, text } = req.body;
  const group = await Group.findById(req.params.id);
  if (!group) return res.status(404).json({ error: "Group not found" });
  group.messages.push({ sender: userId, text });
  await group.save();
  res.json(group);
});

module.exports = router;