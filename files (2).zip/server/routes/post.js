const express = require("express");
const router = express.Router();
const Post = require("../models/Post");

// Get all posts
router.get("/", async (req, res) => {
  const posts = await Post.find().populate("author", "username avatar").sort({ createdAt: -1 });
  res.json(posts);
});

// Create post
router.post("/", async (req, res) => {
  const { author, content } = req.body;
  const post = new Post({ author, content });
  await post.save();
  res.status(201).json(post);
});

// Like/unlike post
router.post("/:id/like", async (req, res) => {
  const { userId } = req.body;
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ error: "Post not found" });
  const idx = post.likes.indexOf(userId);
  if (idx === -1) {
    post.likes.push(userId);
  } else {
    post.likes.splice(idx, 1);
  }
  await post.save();
  res.json(post);
});

// Comment on post
router.post("/:id/comment", async (req, res) => {
  const { userId, text } = req.body;
  const post = await Post.findById(req.params.id);
  if (!post) return res.status(404).json({ error: "Post not found" });
  post.comments.push({ user: userId, text });
  await post.save();
  res.json(post);
});

module.exports = router;